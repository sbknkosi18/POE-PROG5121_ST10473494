/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QuickChat;

/**
 *
 * @author RC_Student_lab
 */
import javax.swing.JOptionPane;

public class QuickChat {
    private static boolean isLoggedIn = false;
    
    public static void main(String[] args) {
        // Login
        login();
        
        if (!isLoggedIn) {
            JOptionPane.showMessageDialog(null, "Login failed. Exiting application.");
            return;
        }
        
        // Welcome message
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.");
        
        // Main application loop
        boolean running = true;
        while (running) {
            String[] options = {"Send Messages", "Show recently sent messages", "Quit"};
            int choice = JOptionPane.showOptionDialog(null, 
                    "Please select an option:", 
                    "QuickChat Menu", 
                    JOptionPane.DEFAULT_OPTION, 
                    JOptionPane.QUESTION_MESSAGE, 
                    null, 
                    options, 
                    options[0]);
            
            if (choice == 0) { // Send Messages
                sendMessages();
            } 
            else if (choice == 1) { // Show recently sent messages
                JOptionPane.showMessageDialog(null, "Coming Soon.");
            } 
            else if (choice == 2) { // Quit
                running = false;
                JOptionPane.showMessageDialog(null, 
                        "Total messages sent: " + Message.returnTotalMessages() + 
                        "\nThank you for using QuickChat!");
            }
        }
    }
    
    private static void login() {
        String username = JOptionPane.showInputDialog("Enter your username:");
        String password = JOptionPane.showInputDialog("Enter your password:");
        
        // Simple validation
        if (username != null && !username.isEmpty() && password != null && !password.isEmpty()) {
            isLoggedIn = true;
        }
    }
    
    private static void sendMessages() {
        try {
            String numMessagesInput = JOptionPane.showInputDialog("How many messages would you like to send?");
            int numMessages = Integer.parseInt(numMessagesInput);
            
            for (int i = 1; i <= numMessages; i++) {
                String recipient = JOptionPane.showInputDialog(
                        "Enter recipient's phone number (include international code if needed):");
                
                // Validate recipient number
                Message tempMsg = new Message(i, recipient, "");
                int recipientCheck = tempMsg.checkRecipientCell();
                if (recipientCheck == -1) {
                    JOptionPane.showMessageDialog(null, 
                            "Cell phone number is incorrectly formatted or does not contain an international code. " +
                            "Please correct the number and try again.");
                    i--; // Retry this message
                    continue;
                }
                
                String messageContent = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
                
                // Validate message length
                if (messageContent.length() > 250) {
                    JOptionPane.showMessageDialog(null, 
                            "Message exceeds 250 characters by " + (messageContent.length() - 250) + 
                            ", please reduce size.");
                    i--; // Retry this message
                    continue;
                }
                
                // Create and process message
                Message message = new Message(i, recipient, messageContent);
                String result = message.sentMessage();
                JOptionPane.showMessageDialog(null, result);
                
                // If sent, show details
                if (message.isSent()) {
                    String details = "Message Details:\n" +
                                    "Message ID: " + message.getMessageId() + "\n" +
                                    "Message Hash: " + message.getMessageHash() + "\n" +
                                    "Recipient: " + message.getRecipient() + "\n" +
                                    "Message: " + message.getMessageContent();
                    JOptionPane.showMessageDialog(null, details);
                }
            }
            
            JOptionPane.showMessageDialog(null, 
                    "Total messages sent in this session: " + Message.returnTotalMessages());
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid number of messages.");
        }
    }
}

