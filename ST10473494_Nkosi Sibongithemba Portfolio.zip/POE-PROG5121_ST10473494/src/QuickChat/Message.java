/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QuickChat;

/**
 *
 * @author RC_Student_lab
 */
import org.json.JSONObject;
import javax.swing.JOptionPane;
import java.util.Random;
import java.util.ArrayList;
import java.util.List;

public class Message {
    private static int totalMessagesSent = 0;
    private static List<Message> sentMessages = new ArrayList<>();
    
    private String messageId;
    private int messageNumber;
    private String recipient;
    private String messageContent;
    private String messageHash;
    private boolean sent;
    private boolean stored;
    
    public Message(int messageNumber, String recipient, String messageContent) {
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.messageContent = messageContent;
        this.messageId = generateMessageId();
        this.messageHash = createMessageHash();
        this.sent = false;
        this.stored = false;
    }
    
    private String generateMessageId() {
        Random random = new Random();
        long id = 1000000000L + random.nextInt(900000000);
        return String.valueOf(id);
    }
    
    public boolean checkMessageId() {
        return messageId != null && messageId.length() == 10;
    }
    
    public int checkRecipientCell() {
        if (recipient == null || recipient.isEmpty()) {
            return -1; // Invalid
        }
        
        // Check international number format
        if (recipient.startsWith("+") && recipient.length() <= 13 && recipient.substring(1).matches("\\d+")) {
            return 1; // Valid international
        }
        
        // Check local number format
        if (recipient.matches("\\d{10}")) {
            return 2; // Valid local
        }
        
        return -1; // Invalid
    }
    
    public String createMessageHash() {
        String[] words = messageContent.split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        
        String hash = messageId.substring(0, 2) + ":" + messageNumber + ":" + 
                     firstWord.toUpperCase() + lastWord.toUpperCase();
        return hash;
    }
    
    public String sentMessage() {
        String[] options = {"Send Message", "Disregard Message", "Store Message to send later"};
        int choice = JOptionPane.showOptionDialog(null, 
                "What would you like to do with this message?", 
                "Message Options", 
                JOptionPane.DEFAULT_OPTION, 
                JOptionPane.QUESTION_MESSAGE, 
                null, 
                options, 
                options[0]);
        
        if (choice == 0) { // Send
            this.sent = true;
            totalMessagesSent++;
            sentMessages.add(this);
            return "Message successfully sent.";
        } 
        else if (choice == 1) { // Disregard
            return "Press 0 to delete message.";
        } 
        else if (choice == 2) { // Store
            this.stored = true;
            storeMessage();
            return "Message successfully stored.";
        } 
        else {
            return "No action taken on message.";
        }
    }
    
    public static String printMessages() {
        StringBuilder sb = new StringBuilder();
        for (Message msg : sentMessages) {
            sb.append("Message ID: ").append(msg.messageId).append("\n")
              .append("Message Hash: ").append(msg.messageHash).append("\n")
              .append("Recipient: ").append(msg.recipient).append("\n")
              .append("Message: ").append(msg.messageContent).append("\n\n");
        }
        return sb.toString();
    }
    
    public static int returnTotalMessages() {
        return totalMessagesSent;
    }
    
    public void storeMessage() {
        JSONObject jsonMessage = new JSONObject();
        jsonMessage.put("messageId", this.messageId);
        jsonMessage.put("messageNumber", this.messageNumber);
        jsonMessage.put("recipient", this.recipient);
        jsonMessage.put("messageContent", this.messageContent);
        jsonMessage.put("messageHash", this.messageHash);
        
        // In a real application, we would write this to a file
        System.out.println("Stored message as JSON: " + jsonMessage.toString());
    }
    
    // Getters
    public String getMessageId() { return messageId; }
    public int getMessageNumber() { return messageNumber; }
    public String getRecipient() { return recipient; }
    public String getMessageContent() { return messageContent; }
    public String getMessageHash() { return messageHash; }
    public boolean isSent() { return sent; }
    public boolean isStored() { return stored; }
}