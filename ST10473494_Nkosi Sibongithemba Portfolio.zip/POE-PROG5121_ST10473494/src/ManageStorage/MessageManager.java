/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ManageStorage;

/**
 *
 * @author RC_Student_lab
 */
import org.json.JSONArray;
import org.json.JSONObject;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

public class MessageManager {
    private JSONArray sentMessages = new JSONArray();
    private JSONArray disregardedMessages = new JSONArray();
    private JSONArray storedMessages = new JSONArray();
    private JSONArray messageHashes = new JSONArray();
    private JSONArray messageIds = new JSONArray();

    public static void main(String[] args) {
        MessageManager manager = new MessageManager();
        manager.loadTestData();
        manager.runDemo();
    }

    public void runDemo() {
        System.out.println("=== Message Management System Demo ===");
        
        // 1. Display senders and recipients
        System.out.println("\n1. All Sent Messages:");
        displaySendersAndRecipients().forEach(System.out::println);
        
        // 2. Find longest message
        System.out.println("\n2. Longest Message:");
        System.out.println(findLongestMessage());
        
        // 3. Search by message ID
        System.out.println("\n3. Search for Message ID 4:");
        System.out.println(searchByMessageId("4"));
        
        // 4. Search by recipient
        System.out.println("\n4. Messages for +27838884567:");
        searchByRecipient("+27838884567").forEach(System.out::println);
        
        // 5. Delete by hash (delete the second message)
        System.out.println("\n5. Deleting message with hash " + messageHashes.getString(1) + ":");
        System.out.println(deleteByHash(messageHashes.getString(1)));
        
        // 6. Generate report
        System.out.println("\n6. Message Report:");
        generateReport().forEach(obj -> {
            JSONObject msg = (JSONObject) obj;
            System.out.println("Hash: " + msg.getString("Message Hash"));
            System.out.println("Recipient: " + msg.getString("Recipient"));
            System.out.println("Message: " + msg.getString("Message"));
            System.out.println("Status: " + msg.getString("Status"));
            System.out.println();
        });
    }

    public void loadTestData() {
        // Test Data Message 1
        addMessage(new Message("+27834557896", "Did you get the cake?", "Sent", "1"));
        
        // Test Data Message 2
        addMessage(new Message("+27838884567", "Where are you? You are late! I have asked you to be on time.", "Stored", "2"));
        
        // Test Data Message 3
        addMessage(new Message("+27834484567", "Yohoooo, I am at your gate.", "Disregard", "3"));
        
        // Test Data Message 4
        addMessage(new Message("0838884567", "It is dinner time !", "Sent", "4"));
        
        // Test Data Message 5
        addMessage(new Message("+27838884567", "Ok, I am leaving without you.", "Stored", "5"));
    }

    private void addMessage(Message message) {
        try {
            String hash = generateHash(message);
            messageHashes.put(hash);
            messageIds.put(message.getMessageId());
            
            String flag = message.getFlag();
            if ("Sent".equals(flag)) {
                sentMessages.put(message.toJson());
            } else if ("Stored".equals(flag)) {
                storedMessages.put(message.toJson());
            } else if ("Disregard".equals(flag)) {
                disregardedMessages.put(message.toJson());
            }
        } catch (NoSuchAlgorithmException e) {
            System.err.println("Error generating hash: " + e.getMessage());
        }
    }

    private String generateHash(Message message) throws NoSuchAlgorithmException {
        String input = message.getRecipient() + message.getMessage() + message.getFlag();
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hashBytes = digest.digest(input.getBytes());
        
        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        
        return hexString.toString();
    }

    public List<String> displaySendersAndRecipients() {
        List<String> result = new ArrayList<>();
        for (int i = 0; i < sentMessages.length(); i++) {
            JSONObject msg = sentMessages.getJSONObject(i);
            result.add("Recipient: " + msg.getString("recipient") + ", Message: " + msg.getString("message"));
        }
        return result;
    }

    public String findLongestMessage() {
        if (sentMessages.length() == 0) {
            return null;
        }
        
        JSONObject longest = sentMessages.getJSONObject(0);
        for (int i = 1; i < sentMessages.length(); i++) {
            JSONObject current = sentMessages.getJSONObject(i);
            if (current.getString("message").length() > longest.getString("message").length()) {
                longest = current;
            }
        }
        return longest.getString("message");
    }

    public String searchByMessageId(String msgId) {
        JSONObject found = findMessageById(msgId);
        if (found != null) {
            return "Recipient: " + found.getString("recipient") + ", Message: " + found.getString("message");
        }
        return "Message not found";
    }

    private JSONObject findMessageById(String msgId) {
        for (int i = 0; i < sentMessages.length(); i++) {
            JSONObject msg = sentMessages.getJSONObject(i);
            if (msg.getString("messageId").equals(msgId)) {
                return msg;
            }
        }
        for (int i = 0; i < storedMessages.length(); i++) {
            JSONObject msg = storedMessages.getJSONObject(i);
            if (msg.getString("messageId").equals(msgId)) {
                return msg;
            }
        }
        for (int i = 0; i < disregardedMessages.length(); i++) {
            JSONObject msg = disregardedMessages.getJSONObject(i);
            if (msg.getString("messageId").equals(msgId)) {
                return msg;
            }
        }
        return null;
    }

    public List<String> searchByRecipient(String recipient) {
        List<String> result = new ArrayList<>();
        addMessagesByRecipient(result, sentMessages, recipient);
        addMessagesByRecipient(result, storedMessages, recipient);
        addMessagesByRecipient(result, disregardedMessages, recipient);
        return result;
    }

    private void addMessagesByRecipient(List<String> result, JSONArray messages, String recipient) {
        for (int i = 0; i < messages.length(); i++) {
            JSONObject msg = messages.getJSONObject(i);
            if (msg.getString("recipient").equals(recipient)) {
                result.add(msg.getString("message"));
            }
        }
    }

    public String deleteByHash(String msgHash) {
        for (int i = 0; i < messageHashes.length(); i++) {
            if (messageHashes.getString(i).equals(msgHash)) {
                String msgId = messageIds.getString(i);
                messageHashes.remove(i);
                messageIds.remove(i);
                
                JSONObject deleted = removeFromArray(sentMessages, msgId);
                if (deleted != null) {
                    return "Message \"" + deleted.getString("message") + "\" successfully deleted.";
                }
                
                deleted = removeFromArray(storedMessages, msgId);
                if (deleted != null) {
                    return "Message \"" + deleted.getString("message") + "\" successfully deleted.";
                }
                
                deleted = removeFromArray(disregardedMessages, msgId);
                if (deleted != null) {
                    return "Message \"" + deleted.getString("message") + "\" successfully deleted.";
                }
                
                return "Message not found in any category";
            }
        }
        return "Message hash not found";
    }

    private JSONObject removeFromArray(JSONArray array, String msgId) {
        for (int i = 0; i < array.length(); i++) {
            JSONObject msg = array.getJSONObject(i);
            if (msg.getString("messageId").equals(msgId)) {
                JSONObject removed = new JSONObject(msg.toString());
                array.remove(i);
                return removed;
            }
        }
        return null;
    }

    public JSONArray generateReport() {
        JSONArray report = new JSONArray();
        for (int i = 0; i < sentMessages.length(); i++) {
            try {
                JSONObject msg = sentMessages.getJSONObject(i);
                Message message = new Message(msg);
                String hash = generateHash(message);
                
                JSONObject entry = new JSONObject();
                entry.put("Message Hash", hash);
                entry.put("Recipient", message.getRecipient());
                entry.put("Message", message.getMessage());
                entry.put("Status", message.getFlag());
                report.put(entry);
            } catch (NoSuchAlgorithmException e) {
                System.err.println("Error generating hash for report: " + e.getMessage());
            }
        }
        return report;
    }
}

class Message {
    private JSONObject messageData;

    public Message(String recipient, String message, String flag, String messageId) {
        this.messageData = new JSONObject();
        this.messageData.put("recipient", recipient);
        this.messageData.put("message", message);
        this.messageData.put("flag", flag);
        this.messageData.put("messageId", messageId);
    }

    public Message(JSONObject json) {
        this.messageData = json;
    }

    public String getRecipient() { return messageData.getString("recipient"); }
    public String getMessage() { return messageData.getString("message"); }
    public String getFlag() { return messageData.getString("flag"); }
    public String getMessageId() { return messageData.getString("messageId"); }

    public JSONObject toJson() {
        return messageData;
    }
}