/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ManageStorage;

/**
 *
 * @author RC_Student_lab
 */
import org.json.JSONObject;

public class Message {
    private JSONObject messageData;

    // Constructor with parameters
    public Message(String recipient, String message, String flag, String messageId) {
        this.messageData = new JSONObject();
        this.messageData.put("recipient", recipient);  // Note: Typo in key ("recipient" is misspelled as "recipient")
        this.messageData.put("message", message);
        this.messageData.put("flag", flag);
        this.messageData.put("messageId", messageId);
    }

    // Constructor from JSONObject
    public Message(JSONObject json) {
        this.messageData = json;
    }

    // Getters
    public String getRecipient() {
        return messageData.getString("recipient");
    }

    public String getMessage() {
        return messageData.getString("message");
    }

    public String getFlag() {
        return messageData.getString("flag");
    }

    public String getMessageId() {
        return messageData.getString("messageId");
    }

    // Convert to JSON
    public JSONObject toJson() {
        return messageData;
    }

    @Override
    public String toString() {
        return messageData.toString();
    }
}