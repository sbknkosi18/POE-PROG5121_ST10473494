/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package ManageStorage;

import java.util.List;
import org.json.JSONArray;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class MessageManagerTest {
    
    public MessageManagerTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of main method, of class MessageManager.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        MessageManager.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of runDemo method, of class MessageManager.
     */
    @Test
    public void testRunDemo() {
        System.out.println("runDemo");
        MessageManager instance = new MessageManager();
        instance.runDemo();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of loadTestData method, of class MessageManager.
     */
    @Test
    public void testLoadTestData() {
        System.out.println("loadTestData");
        MessageManager instance = new MessageManager();
        instance.loadTestData();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displaySendersAndRecipients method, of class MessageManager.
     */
    @Test
    public void testDisplaySendersAndRecipients() {
        System.out.println("displaySendersAndRecipients");
        MessageManager instance = new MessageManager();
        List<String> expResult = null;
        List<String> result = instance.displaySendersAndRecipients();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of findLongestMessage method, of class MessageManager.
     */
    @Test
    public void testFindLongestMessage() {
        System.out.println("findLongestMessage");
        MessageManager instance = new MessageManager();
        String expResult = "";
        String result = instance.findLongestMessage();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchByMessageId method, of class MessageManager.
     */
    @Test
    public void testSearchByMessageId() {
        System.out.println("searchByMessageId");
        String msgId = "";
        MessageManager instance = new MessageManager();
        String expResult = "";
        String result = instance.searchByMessageId(msgId);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchByRecipient method, of class MessageManager.
     */
    @Test
    public void testSearchByRecipient() {
        System.out.println("searchByRecipient");
        String recipient = "";
        MessageManager instance = new MessageManager();
        List<String> expResult = null;
        List<String> result = instance.searchByRecipient(recipient);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteByHash method, of class MessageManager.
     */
    @Test
    public void testDeleteByHash() {
        System.out.println("deleteByHash");
        String msgHash = "";
        MessageManager instance = new MessageManager();
        String expResult = "";
        String result = instance.deleteByHash(msgHash);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateReport method, of class MessageManager.
     */
    @Test
    public void testGenerateReport() {
        System.out.println("generateReport");
        MessageManager instance = new MessageManager();
        JSONArray expResult = null;
        JSONArray result = instance.generateReport();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
