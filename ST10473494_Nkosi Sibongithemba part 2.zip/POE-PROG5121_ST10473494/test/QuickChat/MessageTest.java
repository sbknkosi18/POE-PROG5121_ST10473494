/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package QuickChat;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    @Test
    public void testMessageIDLength() {
        Message msg = new Message("+27718693002", "Hello, this is a test message.", 1);
        assertTrue(msg.checkMessageID(), "Message ID should be exactly 10 characters long.");
    }

    @Test
    public void testRecipientFormat() {
        Message validMsg = new Message("+27718693002", "Test message", 1);
        Message invalidMsg = new Message("08575975889", "Test message", 2);

        assertTrue(validMsg.checkRecipientCell(), "Valid recipient format should pass.");
        assertFalse(invalidMsg.checkRecipientCell(), "Invalid recipient format should fail.");
    }

    @Test
    public void testMessageHashGeneration() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight", 1);
        assertEquals("00:1:HITONIGHT", msg.createMessageHash(), "Message hash does not match expected format.");
    }

    @Test
    public void testSendMessage() {
        Message msg = new Message("+27718693002", "Hello, this is a test message.", 1);
        assertEquals("Message successfully sent.", msg.sendMessage(), "Send message should return success message.");
    }

    @Test
    public void testStoreMessage() {
        Message msg = new Message("+27718693002", "Hello, this is a test message.", 1);
        assertEquals("Message successfully stored.", msg.storeMessage(), "Store message should return success message.");
    }
}