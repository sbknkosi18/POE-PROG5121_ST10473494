/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QuickChat;

/**
 *
 * @author RC_Student_lab
 */
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class MessageStorage {
    private static final String FILE_NAME = "messages.txt";

    // Store message as plain text
    public static void storeMessage(Message msg) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME, true))) {
            writer.write(msg.printMessages());
            writer.newLine();
            System.out.println("Message stored successfully.");
        } catch (IOException e) {
            System.out.println("Error storing message: " + e.getMessage());
        }
    }

    // Load messages from text file
    public static List<String> loadMessages() {
        List<String> messages = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                messages.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error loading messages: " + e.getMessage());
        }
        return messages;
    }
}
