/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
/*
* This test code was developed with the assistance of ChatGPT by OpenAI
 * (https://openai.com/chatgpt), using the GPT-4 model, based on specifications
 * provided for educational and development purposes.
*/
package QuickChat;

/**
 *
 * @author RC_Student_lab
 */
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class QuickChatApp {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat!");

        List<Message> sentMessages = new ArrayList<>();
        int numMessages = 0;

        // Handle incorrect input
        while (true) {
            try {
                numMessages = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of messages to send:"));
                if (numMessages > 0) break;
                JOptionPane.showMessageDialog(null, "Please enter a valid number greater than zero.");
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a numeric value.");
            }
        }

        for (int i = 0; i < numMessages; i++) {
            String recipient = JOptionPane.showInputDialog("Enter recipient phone number:");
            String message = JOptionPane.showInputDialog("Enter message:");

            Message msg = new Message(recipient, message, i + 1);

            if (!msg.checkRecipientCell()) {
                JOptionPane.showMessageDialog(null, "Invalid phone number format.");
                continue;
            }

            if (message.length() > 250) {
                JOptionPane.showMessageDialog(null, "Message exceeds 250 characters by " + (message.length() - 250) + ", please reduce size.");
                continue;
            }

            Object[] options = {"Send Message", "Disregard Message", "Store Message to send later"};
            int choice = JOptionPane.showOptionDialog(null, "Select an option:",
                    "Message Options", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                    null, options, options[0]);

            if (choice == 0) {
                sentMessages.add(msg);
                JOptionPane.showMessageDialog(null, "Message successfully sent.");
            } else if (choice == 1) {
                JOptionPane.showMessageDialog(null, "Press 0 to delete message.");
            } else if (choice == 2) {
                MessageStorage.storeMessage(msg);
            }
        }

        JOptionPane.showMessageDialog(null, "Total messages sent: " + sentMessages.size());
    }
}