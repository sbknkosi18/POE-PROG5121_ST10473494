/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/*
* This test code was developed with the assistance of ChatGPT by OpenAI
 * (https://openai.com/chatgpt), using the GPT-4 model, based on specifications
 * provided for educational and development purposes.
*/
package QuickChat;

/**
 *
 * @author RC_Student_lab
 */
import java.util.Random;

public class Message {
    private String messageID;
    private String recipient;
    private String message;
    private String messageHash;
    private int numMessagesSent;

    public Message(String recipient, String message, int numMessagesSent) {
        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.message = message;
        this.numMessagesSent = numMessagesSent;
        this.messageHash = createMessageHash();
    }

    // Generate a unique 10-digit Message ID
    private String generateMessageID() {
        Random rand = new Random();
        return String.format("%010d", rand.nextInt(1000000000));
    }

    // Ensure Message ID is exactly 10 characters
    public boolean checkMessageID() {
        return messageID.length() == 10;
    }

    // Validate recipient cell number format
    public boolean checkRecipientCell() {
        return recipient.matches("^\\+?\\d{10}$");
    }

    // Generate Message Hash: First two digits of ID, message number, first and last words
    public String createMessageHash() {
        String[] words = message.split(" ");
        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        return messageID.substring(0, 2) + ":" + numMessagesSent + ":" + firstWord + lastWord;
    }

    // Simulate sending the message
    public String sendMessage() {
        return "Message successfully sent.";
    }

    // Store message instead of sending
    public String storeMessage() {
        return "Message successfully stored.";
    }

    // Print all message details
    public String printMessages() {
        return "Message ID: " + messageID + "\nMessage Hash: " + messageHash +
               "\nRecipient: " + recipient + "\nMessage: " + message;
    }

    // Return total number of messages sent
    public int returnTotalMessages() {
        return numMessagesSent;
    }
}